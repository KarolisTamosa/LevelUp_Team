﻿namespace Negocio
{
    public class Divisa
    {
        public string Nombre { get; set; }
        public decimal ValorEnDolares { get; set; }
    }
}
