﻿namespace Negocio
{

    public enum AccionesMenuPrincipal
    {
        ConvertirMoneda = 1,
        MostrarListadoDivisas = 2,
        EditorDeListadoDivisas = 3,
        MostrarHistorialConversiones = 4,
        Salir = 5
    }
    public enum AccionesMenuEditarDivisas
    {
        ModificarUnaDivisa = 1,
        AgregarNuevaDivisa = 2,
        EliminarUnaDivisa = 3,
        ResetearTodoListadoDivisas = 4,
        Salir = 5
    }
    public enum AccionesMenuVolverSalir
    {
        VolverAtras = 1,
        Salir = 2
    }
}
